# README.md
# Ticketing App

A cross-platform (Android & iOS) Jira-like ticketing app built with Flutter and Supabase.

## Setup Instructions
1. Upload this folder to your GitHub repository.
2. Open in GitHub Codespaces.
3. Install dependencies: `flutter pub get`
4. Replace credentials in `lib/constants.dart` with your Supabase and Razorpay keys.
5. Run the app: `flutter run -d web-server`

## Features
- User roles: Customer, Expert, Admin
- Ticket creation with payment slider
- Razorpay payment integration (test mode)
- In-app chat via Firebase
- Masked calling via Jitsi
- Admin panel for certification and disputes
- Security: RLS, AES-256 encryption

## Notes
- Replace Supabase and Firebase credentials in `constants.dart`.
- Configure Supabase RLS policies in the Supabase dashboard.
- Jitsi screen sharing requires additional setup.