# lib/screens/auth/register.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../expert/expert_onboarding.dart';

class RegisterScreen extends StatelessWidget {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _roleController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Register')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            TextField(
              controller: _roleController,
              decoration: InputDecoration(labelText: 'Role (customer/expert/admin)'),
            ),
            ElevatedButton(
              onPressed: () async {
                final role = _roleController.text.toLowerCase();
                final response = await Supabase.instance.client.auth.signUp(
                  email: _emailController.text,
                  password: _passwordController.text,
                );
                if (response.user != null) {
                  await Supabase.instance.client.from('users').insert({
                    'id': response.user!.id,
                    'email': _emailController.text,
                    'role': role,
                    'is_verified': role == 'expert' ? false : true,
                  });
                  if (role == 'expert') {
                    Navigator.pushNamed(context, '/expert/onboarding');
                  } else {
                    Navigator.pushNamed(context, '/login');
                  }
                }
              },
              child: Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}