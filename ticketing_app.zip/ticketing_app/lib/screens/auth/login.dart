# lib/screens/auth/login.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../customer/create_ticket.dart';
import '../expert/ticket_assign.dart';
import '../admin/admin_dashboard.dart';

class LoginScreen extends StatelessWidget {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            ElevatedButton(
              onPressed: () async {
                final response = await Supabase.instance.client.auth.signInWithPassword(
                  email: _emailController.text,
                  password: _passwordController.text,
                );
                if (response.user != null) {
                  final userData = await Supabase.instance.client
                      .from('users')
                      .select()
                      .eq('id', response.user!.id)
                      .single();
                  if (userData['role'] == 'customer') {
                    Navigator.pushReplacementNamed(context, '/customer/tickets');
                  } else if (userData['role'] == 'expert' && userData['is_verified']) {
                    Navigator.pushReplacementNamed(context, '/expert/tickets');
                  } else if (userData['role'] == 'admin') {
                    Navigator.pushReplacementNamed(context, '/admin/dashboard');
                  }
                }
              },
              child: Text('Login'),
            ),
            TextButton(
              onPressed: () => Navigator.pushNamed(context, '/register'),
              child: Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}