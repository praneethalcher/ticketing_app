# lib/screens/admin/admin_dashboard.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AdminDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Admin Dashboard')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, '/admin/certify'),
              child: Text('Review Expert Certifications'),
            ),
            FutureBuilder(
              future: Supabase.instance.client.from('tickets').select().eq('status', 'disputed'),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return CircularProgressIndicator();
                final tickets = snapshot.data as List<dynamic>;
                return Expanded(
                  child: ListView.builder(
                    itemCount: tickets.length,
                    itemBuilder: (context, index) {
                      final ticket = Ticket.fromJson(tickets[index]);
                      return ListTile(
                        title: Text(ticket.title),
                        subtitle: Text('Disputed | Payment: ₹${ticket.paymentAmount}'),
                        onTap: () => _handleDispute(context, ticket),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _handleDispute(BuildContext context, Ticket ticket) async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Resolve Dispute: ${ticket.title}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () async {
                await Supabase.instance.client
                    .from('tickets')
                    .update({'status': 'closed'})
                    .eq('id', ticket.id);
                Navigator.pop(context);
              },
              child: Text('Approve Resolution'),
            ),
            ElevatedButton(
              onPressed: () async {
                await Supabase.instance.client
                    .from('tickets')
                    .update({'status': 'closed'})
                    .eq('id', ticket.id);
                Navigator.pop(context);
              },
              child: Text('Refund Customer'),
            ),
          ],
        ),
      ),
    );
  }
}