# lib/screens/admin/certify_expert.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CertifyExpertScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Certify Experts')),
      body: FutureBuilder(
        future: Supabase.instance.client
            .from('users')
            .select()
            .eq('role', 'expert')
            .eq('is_verified', false),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return CircularProgressIndicator();
          final experts = snapshot.data as List<dynamic>;
          return ListView.builder(
            itemCount: experts.length,
            itemBuilder: (context, index) {
              final expert = User.fromJson(experts[index]);
              return ListTile(
                title: Text(expert.email),
                subtitle: Text('Pending Certification'),
                onTap: () async {
                  await Supabase.instance.client
                      .from('users')
                      .update({'is_verified': true})
                      .eq('id', expert.id);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Expert Verified')),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}