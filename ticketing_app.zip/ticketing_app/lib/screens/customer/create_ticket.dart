# lib/screens/customer/create_ticket.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../widgets/payment_slider.dart';
import '../../utils/encryption.dart';

class CreateTicketScreen extends StatelessWidget {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _categoryController = TextEditingController();
  final _paymentController = TextEditingController(text: '500');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Create Ticket')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            TextField(
              controller: _categoryController,
              decoration: InputDecoration(labelText: 'Category (e.g., construction, marriage)'),
            ),
            PaymentSlider(
              initialValue: 500,
              minValue: 500,
              maxValue: 5000,
              onChanged: (value) => _paymentController.text = value.toStringAsFixed(0),
            ),
            ElevatedButton(
              onPressed: () async {
                final user = Supabase.instance.client.auth.currentUser;
                final ticketData = {
                  'id': DateTime.now().millisecondsSinceEpoch.toString(),
                  'user_id': user!.id,
                  'category': _categoryController.text,
                  'title': encrypt(_titleController.text),
                  'description': encrypt(_descriptionController.text),
                  'status': 'open',
                  'payment_amount': double.parse(_paymentController.text),
                };
                await Supabase.instance.client.from('tickets').insert(ticketData);
                Navigator.pop(context);
              },
              child: Text('Submit Ticket'),
            ),
          ],
        ),
      ),
    );
  }
}
