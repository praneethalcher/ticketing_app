# lib/screens/expert/ticket_assign.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/chat_service.dart';

class TicketAssignScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Available Tickets')),
      body: FutureBuilder(
        future: Supabase.instance.client
            .from('tickets')
            .select()
            .eq('status', 'open'),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return CircularProgressIndicator();
          final tickets = snapshot.data as List<dynamic>;
          return ListView.builder(
            itemCount: tickets.length,
            itemBuilder: (context, index) {
              final ticket = Ticket.fromJson(tickets[index]);
              return ListTile(
                title: Text(ticket.title),
                subtitle: Text('Category: ${ticket.category} | Payment: ₹${ticket.paymentAmount}'),
                onTap: () async {
                  final user = Supabase.instance.client.auth.currentUser;
                  await Supabase.instance.client
                      .from('tickets')
                      .update({
                        'expert_id': user!.id,
                        'status': 'assigned',
                      })
                      .eq('id', ticket.id);
                  await ChatService().initChat(ticket.id, user.id, ticket.userId);
                  // Navigate to chat screen (not implemented here for simplicity)
                },
              );
            },
          );
        },
      ),
    );
  }
}
