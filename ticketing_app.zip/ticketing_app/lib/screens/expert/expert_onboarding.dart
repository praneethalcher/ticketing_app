# lib/screens/expert/expert_onboarding.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ExpertOnboardingScreen extends StatelessWidget {
  final _categoryController = TextEditingController();
  final _minFeeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Expert Onboarding')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _categoryController,
              decoration: InputDecoration(labelText: 'Category'),
            ),
            TextField(
              controller: _minFeeController,
              decoration: InputDecoration(labelText: 'Minimum Fee (INR)'),
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              onPressed: () async {
                final user = Supabase.instance.client.auth.currentUser;
                final userData = await Supabase.instance.client
                    .from('users')
                    .select()
                    .eq('id', user!.id)
                    .single();
                final updatedFees = Map<String, double>.from(userData['category_fees'] ?? {});
                updatedFees[_categoryController.text] = double.parse(_minFeeController.text);
                await Supabase.instance.client
                    .from('users')
                    .update({'category_fees': updatedFees})
                    .eq('id', user.id);
                Navigator.pushNamed(context, '/expert/tickets');
              },
              child: Text('Submit Certification'),
            ),
          ],
        ),
      ),
    );
  }
}
