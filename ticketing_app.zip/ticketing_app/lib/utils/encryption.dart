# lib/utils/encryption.dart
import 'package:encrypt/encrypt.dart';
import 'package:encrypt/encrypt.dart' as encrypt;

String encrypt(String data) {
  final key = Key.fromUtf8('32-character-long-key-for-aes-256');
  final iv = IV.fromLength(16);
  final encrypter = Encrypter(AES(key));
  return encrypter.encrypt(data, iv: iv).base64;
}

String decrypt(String encryptedData) {
  final key = Key.fromUtf8('32-character-long-key-for-aes-256');
  final iv = IV.fromLength(16);
  final encrypter = Encrypter(AES(key));
  return encrypter.decrypt64(encryptedData, iv: iv);
}
