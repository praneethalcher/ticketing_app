# lib/widgets/payment_slider.dart
import 'package:flutter/material.dart';

class PaymentSlider extends StatelessWidget {
  final double initialValue;
  final double minValue;
  final double maxValue;
  final Function(double) onChanged;

  PaymentSlider({
    required this.initialValue,
    required this.minValue,
    required this.maxValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Slider(
      value: initialValue,
      min: minValue,
      max: maxValue,
      divisions: ((maxValue - minValue) / 100).toInt(),
      label: '₹$initialValue',
      onChanged: onChanged,
    );
  }
}