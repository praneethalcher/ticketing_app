# lib/main.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/auth/login.dart';
import 'constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: SUPABASE_URL,
    anonKey: SUPABASE_ANON_KEY,
  );
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ticketing App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LoginScreen(),
      routes: {
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/customer/tickets': (context) => CreateTicketScreen(),
        '/expert/tickets': (context) => TicketAssignScreen(),
        '/expert/onboarding': (context) => ExpertOnboardingScreen(),
        '/admin/dashboard': (context) => AdminDashboardScreen(),
        '/admin/certify': (context) => CertifyExpertScreen(),
      },
    );
  }
}
