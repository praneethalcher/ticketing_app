# lib/services/chat_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class ChatService {
  final _firestore = FirebaseFirestore.instance;

  Future<void> initChat(String ticketId, String expertId, String customerId) async {
    await _firestore.collection('chats').doc(ticketId).set({
      'ticket_id': ticketId,
      'expert_id': expertId,
      'customer_id': customerId,
      'messages': [],
    });
  }

  Stream<List<Map<String, dynamic>>> getMessages(String ticketId) {
    return _firestore
        .collection('chats')
        .doc(ticketId)
        .snapshots()
        .map((snapshot) => List<Map<String, dynamic>>.from(snapshot.data()?['messages'] ?? []));
  }

  Future<void> sendMessage(String ticketId, String userId, String message) async {
    final filteredMessage = message.replaceAll(RegExp(r'\b\d{10}\b'), '[REDACTED]');
    await _firestore.collection('chats').doc(ticketId).update({
      'messages': FieldValue.arrayUnion([
        {
          'user_id': userId,
          'message': filteredMessage,
          'timestamp': FieldValue.serverTimestamp(),
        }
      ]),
    );
  }
}