# lib/services/payment_service.dart
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../constants.dart';

class PaymentService {
  final _razorpay = Razorpay();

  PaymentService() {
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
  }

  void initiatePayment(double amount, String ticketId) {
    final options = {
      'key': RAZORPAY_KEY,
      'amount': (amount * 100).toInt(),
      'name': 'Ticketing App',
      'description': 'Ticket Payment #$ticketId',
      'prefill': {'contact': '', 'email': ''},
    };
    _razorpay.open(options);
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    // Update ticket status to 'inProgress'
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    // Handle payment failure
  }
}
