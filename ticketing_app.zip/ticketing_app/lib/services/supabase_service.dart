# lib/services/supabase_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  final client = Supabase.instance.client;

  Future<void> setupRLS() async {
    await client.rpc('enable_rls', params: {'table_name': 'tickets'});
    await client.rpc('enable_rls', params: {'table_name': 'users'});
  }

  Future<void> uploadMedia(String filePath, String ticketId) async {
    final fileName = '$ticketId-${DateTime.now().millisecondsSinceEpoch}';
    await client.storage.from('ticket-media').upload(fileName, filePath);
  }
}