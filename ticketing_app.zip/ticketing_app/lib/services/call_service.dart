# lib/services/call_service.dart
import '../constants.dart';

class CallService {
  String generateJitsiRoom(String ticketId) {
    return '$JITSI_SERVER/ticket-$ticketId';
  }

  void startScreenShare(String room) {
    // Jitsi SDK integration for screen sharing
  }
}