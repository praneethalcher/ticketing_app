# lib/constants.dart
const String SUPABASE_URL = 'your-supabase-url'; // Replace with your Supabase URL
const String SUPABASE_ANON_KEY = 'your-supabase-anon-key'; // Replace with your Supabase Anon Key
const String RAZORPAY_KEY = 'rzp_test_dummy1234567890'; // Dummy Razorpay test key
const String JITSI_SERVER = 'meet.jit.si'; // No change needed
