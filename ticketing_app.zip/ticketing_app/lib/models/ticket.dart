# lib/models/ticket.dart
enum TicketStatus { open, assigned, inProgress, resolved, disputed, closed }

class Ticket {
  final String id;
  final String userId;
  final String category;
  final String title;
  final String description;
  final String? mediaUrl;
  final TicketStatus status;
  final double paymentAmount;
  final String? expertId;

  Ticket({
    required this.id,
    required this.userId,
    required this.category,
    required this.title,
    required this.description,
    this.mediaUrl,
    required this.status,
    required this.paymentAmount,
    this.expertId,
  });

  factory Ticket.fromJson(Map<String, dynamic> json) {
    return Ticket(
      id: json['id'],
      userId: json['user_id'],
      category: json['category'],
      title: json['title'],
      description: json['description'],
      mediaUrl: json['media_url'],
      status: TicketStatus.values.firstWhere((e) => e.toString() == 'TicketStatus.${json['status']}'),
      paymentAmount: json['payment_amount'].toDouble(),
      expertId: json['expert_id'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'category': category,
      'title': title,
      'description': description,
      'media_url': mediaUrl,
      'status': status.toString().split('.').last,
      'payment_amount': paymentAmount,
      'expert_id': expertId,
    };
  }
}
