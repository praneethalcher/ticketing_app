# lib/models/user.dart
enum UserRole { customer, expert, admin }

class User {
  final String id;
  final String email;
  final UserRole role;
  final bool isVerified;
  final Map<String, double> categoryFees;

  User({
    required this.id,
    required this.email,
    required this.role,
    this.isVerified = false,
    this.categoryFees = const {},
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      email: json['email'],
      role: UserRole.values.firstWhere((e) => e.toString() == 'UserRole.${json['role']}'),
      isVerified: json['is_verified'] ?? false,
      categoryFees: Map<String, double>.from(json['category_fees'] ?? {}),
    );
  }
}